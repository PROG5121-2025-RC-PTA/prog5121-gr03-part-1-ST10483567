/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import com.mycompany.registration.Message;
import com.mycompany.registration.messageManager;
import java.util.List;
import javax.swing.JOptionPane;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class AssertEqualsTest {
    messageManager manager;
    
    public AssertEqualsTest() {
    }

    @org.junit.jupiter.api.BeforeAll
    public static void setUpClass() throws Exception {
    }

    @org.junit.jupiter.api.AfterAll
    public static void tearDownClass() throws Exception {
    }

    @org.junit.jupiter.api.BeforeEach
    public void setUp() throws Exception {
    }

    @org.junit.jupiter.api.AfterEach
    public void tearDown() throws Exception {
    }
    private static int counter = 0;
        private String id;
        private int number;
        private String hash;

    public void Messages(String recipient, String content) {
            this.number = ++counter;
            this.id = generateID();
            this.hash = createHash(content);
        }
     private String generateID() {
            return String.valueOf(1000000000 + (int)(Math.random() * 900000000));
        }
    private String createHash(String content) {
            String[] words = content.split(" ");
            String first = words[0];
            String last = words[words.length - 1];
            return (id.substring(0, 2) + ":" + number + ":" + first + last).toUpperCase();
        }

        public String getMessageID() {
            return id;
        }

        public int getMessageNumber() {
            return number;
        }

        public String getMessageHash() {
            return hash;
        }
    
    @Test
    public void testMessageLengthValid(){
        Message message = new Message("+27718693002", "Message length", "Disregarded");
        assertTrue(message.getMessageContent().length() <= 250);
    }
    
    //Test correct phone number
    @Test
    public void testRecipientNumberValid(){
        String recipient1 = "+27718693002";
        String recipient2 = "08575975889";
        boolean isValid = recipient1.matches("\\+27\\d{9,10}" );
        boolean alsoValid = recipient2.matches("\\d{9,10}");
        assertTrue(isValid);
        assertTrue(alsoValid);
    }
    
    //Test message hash correct
    @Test
    public void testMessageHash(String messageHash){
        Message message1 = new Message("27718693002", "Hi Mike, can you join us for dinner tonight", "Sent");
        Message message2 = new Message("08575975889", "Hi Keegan, did you receive the payment?", "Sent");
        assertTrue(message1.getMessageHash().matches(messageHash));
        assertTrue(message2.getMessageHash().matches(messageHash));
    }
    //Test messade id correct
     @Test
    public void testMessageIDIsGenerated() {
        Message message = new Message("+27718693002", "Hello", "Sent");
        assertEquals(10, message.getMessageID().length());
        assertTrue(message.getMessageID().matches("\\d{10}"));
    }
     @Test
    public void testSendMessageOption() {
        int option = 0;
        String result = handleMessageOption(option);
        assertEquals("Message successfully sent.", result);
    }

    
    @Test
    public void testDisregardMessageOption() {
        int option = 1;
        String result = handleMessageOption(option);
        assertEquals("Message disregarded.", result);
    }
     
    @Test
    public void testStoreMessageOption() {
        int option = 2;
        String result = handleMessageOption(option);
        assertEquals("Message successfully stored.", result);
    }

    //option handler
    private String handleMessageOption(int option) {
        if (option == 0) {
            return "Message successfully sent.";
        } else if (option == 1) {
            return "Message disregarded.";
        } else if (option == 2) {
            return "Message successfully stored.";
        } else {
            return "Invalid option.";
        }
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}

    private void assertTrue(boolean valid) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    @BeforeEach
    public void seTUp(){
        messageManager manager = new messageManager();
        manager.TestData();
    }
   
    
    @Test
    public void testSentMessagesPopulated(){
        int expected = 2;
        int actual = manager.sentMessages.size();
        JOptionPane.showMessageDialog(null, "Sent Messages "
                + "Popuated: Expected+" + expected + ", Actual = " + 
                actual);
    }
    @Test
    public void testLongestSentMessage(){
        Message longest = manager.getLongestSentMessage();
        String expected = "It is dinner time!";
        JOptionPane.showMessageDialog(null, "Longest sent"
                + "message: " + longest.getMessageContent());
        assertEquals(expected, longest.getMessageContent());
    }
    @Test
    public void testSearchMessageID(){
        String ID = manager.sentMessages.get(0).getMessageID();
        Message result = manager.searchMessageID(ID);
        JOptionPane.showMessageDialog(null, "Message with ID found:"
        + result.getMessageContent());
        assertNotNull(result);
    }
    @Test
    public void testSearchByRecipient(){
        List<Message> messages = manager.searchByRecipient("+27838884567");
        JOptionPane.showMessageDialog(null, "Messages "
                + "to +27838884567: " + messages.size());
        assertEquals(2, messages.size());
    }
    @Test
    public void TestDeleteByHash(){
        Message message = manager.storedMessages.get(0);
        boolean deleted = manager.deleteByHash(message.getMessageHash());
        JOptionPane.showMessageDialog(null, "Messae deleted: " + message.getMessageContent());
        assertTrue(deleted);
    }
}
