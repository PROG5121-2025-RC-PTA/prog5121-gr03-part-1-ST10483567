/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import com.mycompany.registration.Message;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class AssertEqualsTest {
    
    public AssertEqualsTest() {
    }

    @org.junit.jupiter.api.BeforeAll
    public static void setUpClass() throws Exception {
    }

    @org.junit.jupiter.api.AfterAll
    public static void tearDownClass() throws Exception {
    }

    @org.junit.jupiter.api.BeforeEach
    public void setUp() throws Exception {
    }

    @org.junit.jupiter.api.AfterEach
    public void tearDown() throws Exception {
    }
    private static int counter = 0;
        private String id;
        private int number;
        private String hash;

    public void Message(String recipient, String content) {
            this.number = ++counter;
            this.id = generateID();
            this.hash = createHash(content);
        }
     private String generateID() {
            return String.valueOf(1000000000 + (int)(Math.random() * 900000000));
        }
    private String createHash(String content) {
            String[] words = content.split(" ");
            String first = words[0];
            String last = words[words.length - 1];
            return (id.substring(0, 2) + ":" + number + ":" + first + last).toUpperCase();
        }

        public String getMessageID() {
            return id;
        }

        public int getMessageNumber() {
            return number;
        }

        public String getMessageHash() {
            return hash;
        }
    
    @Test
    public void testMessageLengthValid(){
        Message message = new Message("+27718693002", "Message length");
        assertTrue(message.getMessageContent().length() <= 250);
    }
    
    //Test correct phone number
    @Test
    public void testRecipientNumberValid(){
        String recipient = "+27718693002";
        String recupient = "08575975889";
        boolean isValid = recipient.matches("\\+27\\d{9,10}" );
        boolean alsoValid = recipient.matches("\\d{9,10}");
        assertTrue(isValid);
    }
    
    //Test message hash correct
    @Test
    public void testMessageHash(String messageHash){
        Message mesage = new Message("27718693002", "Hi Mike, can you join us for dinner tonight");
        Message msg = new Message("08575975889", "Hi Keegan, did you receive the payment?");
        assertTrue(mesage.getMessageHash().matches(messageHash));
    }
    //Test messade id correct
     @Test
    public void testMessageIDIsGenerated() {
        Message msg = new Message("+27718693002", "Hello");
        assertEquals(10, msg.getMessageID().length());
        assertTrue(msg.getMessageID().matches("\\d{10}"));
    }
     @Test
    public void testSendMessageOption() {
        int option = 0;
        String result = handleMessageOption(option);
        assertEquals("Message successfully sent.", result);
    }

    
    @Test
    public void testDisregardMessageOption() {
        int option = 1;
        String result = handleMessageOption(option);
        assertEquals("Message disregarded.", result);
    }
     
    @Test
    public void testStoreMessageOption() {
        int option = 2;
        String result = handleMessageOption(option);
        assertEquals("Message successfully stored.", result);
    }

    //option handler
    private String handleMessageOption(int option) {
        if (option == 0) {
            return "Message successfully sent.";
        } else if (option == 1) {
            return "Message disregarded.";
        } else if (option == 2) {
            return "Message successfully stored.";
        } else {
            return "Invalid option.";
        }
    }

    
    
    

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}

    private void assertTrue(boolean valid) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
