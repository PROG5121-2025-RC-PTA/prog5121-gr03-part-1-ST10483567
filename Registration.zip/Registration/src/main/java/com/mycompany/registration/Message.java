/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.registration;

import java.util.Random;

/**
 *
 * @author RC_Student_lab
 */
public class Message {
    private int messageNumber;
    private String messageID;
    private String recipient;
    private String messageContent;
    public String messageHash;
    private String generateMessageID;
    
    //construct a new message object
    public Message(String recipient, String messageContent){
        
        this.messageID = generateMessageID();
        this.recipient = recipient;
        this.messageContent = messageContent;
        this.messageHash = createMessageHash();
    }
    //Create a unique 10 digite ID
    private String generateMessageID(){
        Random rand = new Random();
        long number = 1000000000L + (long) (rand.nextDouble() * 9000000000L);
        return String.valueOf(number);
    }
    //Create a message hash in the specific format
    private String createMessageHash(){
        String[] words = messageContent.trim().split(" ");
        //Get the first word of the message
        String firstWord = "";
        if (words.length >= 1){
            firstWord = words[0];
        }
        //get the last word of the message
        String lastWord = "";
        if (words.length >= 2){
            lastWord = words[words.length - 1];
        }
        //if theres only one word
        else {
            lastWord = firstWord;
        }
        //Get the first 2 digits of the message ID
        String firstTwoDigits = messageID.substring(0, 2);
        //build the hash
        String messageHash = firstTwoDigits + ":" + messageNumber + firstWord + lastWord;
        //convert to uppercase
        return messageHash.toUpperCase();
    }
    public String getMessageDetails(){
        //https://www.w3schools.com/java/java_strings_specchars.asp
        return "Message ID: " + messageID +
                "\nMessage Hash: " + messageHash +
                "\nRecipient: " + recipient +
                "\nMessage: " + messageContent;
    }

    public String getMessageContent() {
        return messageContent;
    }
    public String getMessageID(){
        return messageID;
    }
    public String getMessageHash(){
        return messageHash;
    }

   
   
  
    
}
