/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.registration;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author RC_Student_lab
 */
public class messageManager {
    public ArrayList<Message> sentMessages = new ArrayList<>();
    private ArrayList<Message> disregardedMessages = new ArrayList<>();
    public ArrayList<Message> storedMessages = new ArrayList<>();
    private ArrayList<String> messageHashes = new ArrayList<>();
    private ArrayList<String> messageIDs = new ArrayList<>();
    private int messagesToSend;
    private int messagesSent = 0;
    
    public void setMessgaesToSend(int count){
        this.messagesToSend = count;
        this.messagesSent = 0;
    }
    
    public boolean canSendMoreMessages(){
        return messagesSent < messagesToSend;
    }
    
    
    
    
    public void addMessage(Message message) {
        switch (message.flag) {
            case "SEND":
                if (messagesSent < messagesToSend) {
                    sentMessages.add(message);
                    messageHashes.add(message.getMessageHash());
                    messageIDs.add(message.getMessageID());
                    message.flag = "SENT";
                    messagesSent++;
                    JOptionPane.showMessageDialog(null, 
                        "Message sent!\n" + message.getMessageDetails() +
                        "\nMessages sent: " + messagesSent + "/" + messagesToSend);
                } else {
                    JOptionPane.showMessageDialog(null, 
                        "You've reached your limit of " + messagesToSend + " messages.");
                }
                break;
                
            case "STORE":
                storedMessages.add(message);
                message.flag = "STORED";
                JOptionPane.showMessageDialog(null, "Message stored for later.");
                break;
                
            case "DISREGARD":
                disregardedMessages.add(message);
                message.flag = "DISREGARDED";
                 JOptionPane.showMessageDialog(null, "Message disregarded.");
                break;
        }
    }
                      
    //Display the sender and recipient of all sent messages
    public void SenderandRecipient(){
        for(Message messages: sentMessages){
            JOptionPane.showMessageDialog(null, "Recipient: " + messages.getRecipient());
        }
    }
    //Display the longest message
    public Message getLongestSentMessage(){
        Message longest = null;
        for (Message messages : sentMessages){
            if (longest == null || messages.getMessageContent().length() > longest.getMessageContent().length()){
                longest = messages;
            }
        }
        return longest;
    }
    //Search for ID and display corresponding recipient and message
    public Message searchMessageID(String messageID){
        for (Message messages : sentMessages){
            if (messages.getMessageID().equals(messageID))
                return messages;
        }
        return null;
    }
    //Search all messages spent to specific recipient
    public List<Message> searchByRecipient(String recipient){
        List<Message> result = new ArrayList<>();
        for (Message messages : sentMessages){
            if (messages.getRecipient().equals(recipient))result.add(messages);
        }
        for (Message messages : storedMessages){
            if (messages.getRecipient().equals(recipient))result.add(messages);
        }
        return result;
    }
    //Delete a message using the message hash
    public boolean deleteByHash(String messageHash){
        for (Message messages : storedMessages){
            if (messages.getMessageHash().equals(messageHash)){
                storedMessages.remove(messages);
                return true;
            }
        }
        return false;
    }
    //Display the report
    public void Report(){
        StringBuilder report = new StringBuilder();
        for (Message messages : sentMessages){
            report.append("Hash: ").append(messages.getMessageHash())
                    .append("\n").append("Recipient: ").append(messages.getRecipient())
                    .append("\n").append("Messages: ").append(messages.getMessageContent())
                    .append("\n").append("========\n");
        }
        JOptionPane.showMessageDialog(null, report.toString(), "Sent Messages Report", JOptionPane.INFORMATION_MESSAGE);
    }
    
     public void TestData(){
        addMessage(new Message("+27834557896", "Did you get the cake?","Sent"));
        addMessage(new Message("+27838884567", "Where are you? You are late! I have asked you to be on time.", "Stored"));
        addMessage(new Message( "+27838884567", "Yohoooo, I am at your gate.", "Disregarded"));
        addMessage(new Message("0838884567", "It is dinner time!", "Sent"));
        addMessage(new Message("+27838884567", "Ok, I am leaving without you.", "Stored"));
    }
   

    void addMessage(Message message, String send) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
    
}
