/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.registration;

import static com.mycompany.registration.Registration.checkPasswordComplexity;
import javax.swing.JOptionPane;

/**
 *
 * @author RC_Student_lab
 */
public class Login {
    
   
    
    private String registeredUsername;
    private String registeredPassword;
    private boolean loginStatus = false;
    
    public String registerUser(String userName, String password, String cellNumber){
        if(!checkUserName(userName)){
            return "Username is incorrectly formatted.";
        }
        if(!checkPasswordComplexity(password)){
            return "Password does not meet complexity requirements";
        }
        registeredUsername = userName;
        registeredPassword = password;
        
        return "User has been registered sucessfully";
        
        
        
    }
    public boolean loginUser(String inputUserName,String inputPassword){
        if(inputUserName.equals(registeredUsername) && inputPassword.equals(registeredPassword)){
            loginStatus = true;
            return true;
        }
        else{
            loginStatus = false;
            return false;
        } 
    }
    public String returnLoginStatus(){
        if (loginStatus){
            return "Welcome" + registeredUsername;
        }
        else{
            return "Username or password incorrect, please try again";
        }
    }

    private boolean checkUserName(String userName) {
    return userName.length() <= 5 && userName.contains("_");
    }
    
    public String getRegisteredPassword(){
        return registeredPassword;
    }
    public String getRegisteredUsername(){
        return registeredUsername;
    }
}
