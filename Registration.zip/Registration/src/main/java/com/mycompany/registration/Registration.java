/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registration;


import javax.swing.JOptionPane;

/**
 *
 * @author RC_Student_lab
 */
public class Registration {

    private static String password;

    public static void main(String[] args) {
        
        //Enter Username
        String username = JOptionPane.showInputDialog("Enter a username ");
        
        if (checkUsername(username)) {
            JOptionPane.showMessageDialog(null, "welcome " + username + " it is great to see you");
        }
        else {
            JOptionPane.showMessageDialog(null, "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters long");
            
        }

        //enter password
        String password = JOptionPane.showInputDialog(null, "Enter your password");
        if (checkPasswordComplexity (password)){
            JOptionPane.showMessageDialog(null, "password successfully captured");
        }
        else {
            JOptionPane.showMessageDialog(null, "Password is not correctly formatted, please ensure that password contains at least eight characters, a capital letter, a number and a special character.");
        }
        //Enter cell number
        String cellNumber = JOptionPane.showInputDialog(null, "Enter your South African cellphone number (e.g. +27833541899)");
        if (checkCellphoneNumber(cellNumber)){
            JOptionPane.showMessageDialog(null, "Cell phone number successfully captured");
        }
        else{
            JOptionPane.showMessageDialog(null, "Cell phone number  incorrectly formatted or does not contain international code");

        }
        String registeredUsername = username;
        String registeredpassword = password;
       
    }
    //Username conditions
    public static boolean checkUsername(String userName){
        if (userName.length()<=5 && userName.contains("_")){
            }
        return true;
    }
    //Password conditions
    public static boolean checkPasswordComplexity(String password){
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecialChar = false;
        
        if(password.length()<8){
            return false;
        }
        for (int i=0; i < password.length(); i++){
            char c = password.charAt(i);
            if(Character.isUpperCase(c)){
                hasCapital = true;
            }
            if(Character.isDigit(c)){
                hasNumber = true;
            }
            if(!Character.isLetterOrDigit(c)){
                hasSpecialChar = true;
            }
        }
        return hasCapital && hasNumber && hasSpecialChar;
    }
    //Cell number conditions
    //Phone number validation method developed with guidance from ChatGPT 
    //OpenAI.(2025). ChatGPT(April 10 version).https://chatgpt.com/c/67f832f3-9424-8002-9024-b2da62f7d8f9
    public static boolean checkCellphoneNumber(String cellNumber){
        if (cellNumber.length() !=12 ){
            return false;
        }
        if (!cellNumber.startsWith("+27")){   
        return false;
        }
        for (int i=3; i<cellNumber.length(); i++){
            char c = cellNumber.charAt(i);
            if(!Character.isDigit(c)){
                return false;
            }
        }
        return true;
    }
        
}
