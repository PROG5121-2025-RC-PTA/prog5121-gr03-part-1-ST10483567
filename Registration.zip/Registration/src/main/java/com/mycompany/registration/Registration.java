/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registration;


import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.lang.reflect.Type;
import static java.nio.channels.Channels.newWriter;
import java.util.Arrays;


/**
 *
 * @author RC_Student_lab
 */
public class Registration {

    private static String password; 
    public static int messageCounter = 0;
    private static List<Message> sentMessages;
    public static String registeredUsername;
    public static String registeredpassword = password;
    private static String flag;
    
    

    public static void main(String[] args) {
        sentMessages = new ArrayList<>();
        //Enter Username
        String username = JOptionPane.showInputDialog("Enter a username ");
        
        if (checkUsername(username)) {
            JOptionPane.showMessageDialog(null, "welcome " + username + " it is great to see you");
        }
        else {
            JOptionPane.showMessageDialog(null, "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters long");
            
        }

        //enter password
        String password = JOptionPane.showInputDialog(null, "Enter your password");
        if (checkPasswordComplexity (password)){
            JOptionPane.showMessageDialog(null, "password successfully captured");
        }
        else {
            JOptionPane.showMessageDialog(null, "Password is not correctly formatted, please ensure that password contains at least eight characters, a capital letter, a number and a special character.");
        }
        //Enter cell number
        String cellNumber = JOptionPane.showInputDialog(null, "Enter your South African cellphone number (e.g. +27833541899)");
        if (checkCellphoneNumber(cellNumber)){
            JOptionPane.showMessageDialog(null, "Cell phone number successfully captured");
        }
        else{
            JOptionPane.showMessageDialog(null, "Cell phone number  incorrectly formatted or does not contain international code");

        }
        
        
        if (!loginUser()){
            JOptionPane.showMessageDialog(null, "Login Failed");
            
        }
        else{
            JOptionPane.showMessageDialog(null, "Welcome to QuickChat");
        }
        while (true){
            String[] options = {"1.Send messages", "2.Show recently sent messages", "3.Quit"};
            int choice = JOptionPane.showOptionDialog(null, "Choose an option", "Menu", JOptionPane.INFORMATION_MESSAGE, JOptionPane.DEFAULT_OPTION, null, options, options); 
            
            switch (choice){
                case 0:
                    //prompt user for the number of messages to send
                    int totalMessages = getTotalMessages();
                    sendMessages(totalMessages);
                    break;
                case 1:
                    //option 2 under development
                    JOptionPane.showMessageDialog(null, "Coming soon");
                    break;
                case 2:
                    //quit
                    System.exit(0);     
            }
        }
    }
    //Username conditions
    public static boolean checkUsername(String userName){
        if (userName.length()<=5 && userName.contains("_")){
            }
        return true;
    }
    //Password conditions
    public static boolean checkPasswordComplexity(String password){
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecialChar = false;
        
        if(password.length()<8){
            return false;
        }
        for (int i=0; i < password.length(); i++){
            char c = password.charAt(i);
            if(Character.isUpperCase(c)){
                hasCapital = true;
            }
            if(Character.isDigit(c)){
                hasNumber = true;
            }
            if(!Character.isLetterOrDigit(c)){
                hasSpecialChar = true;
            }
        }
        return hasCapital && hasNumber && hasSpecialChar;
    }
    //Cell number conditions
    //Phone number validation method developed with guidance from ChatGPT 
    //OpenAI.(2025). ChatGPT(April 10 version).https://chatgpt.com/c/67f832f3-9424-8002-9024-b2da62f7d8f9
    public static boolean checkCellphoneNumber(String cellNumber){
        if (cellNumber.length() !=12 ){
            return false;
        }
        if (!cellNumber.startsWith("+27")){   
        return false;
        }
        for (int i=3; i<cellNumber.length(); i++){
            char c = cellNumber.charAt(i);
            if(!Character.isDigit(c)){
                return false;
            }
        }
        return true;
    }

    private static boolean loginUser() {
    String inputUsername = JOptionPane.showInputDialog(null, "Enter your username to login");
    String inputPassword = JOptionPane.showInputDialog(null, "Enter your password to login");

    return inputUsername.equals(registeredUsername) && inputPassword.equals(registeredpassword);
    }
    
    private static int getTotalMessages(){
        while (true){
            String input = JOptionPane.showInputDialog("How many messages would you like to send?");
            int count = Integer.parseInt(input);
            if (count > 0){
                return count;
            }
            else {
                JOptionPane.showMessageDialog(null, "Invalid number. Please try again");
                
            }
        }
    }
    private static String getRecipientNumber(){
        while (true){
            String recipient = JOptionPane.showInputDialog("Enter recipient's cellphone number, including the international code");
            //Validate cellphone number format
            /*https://www.w3schools.com/js/js_regexp.asp
              https://youtu.be/NlCF54RIq1k?si=w5BAH6dbrZ5GsXRj
              https://youtu.be/kH6P540D8P0?si=Cl2o4XJKrCUNZ8AM*/
            if (recipient.matches("\\+27\\d{9,10}")){
                return recipient;
            }
            else{
                 JOptionPane.showMessageDialog(null, "Invalid number. Ensure number contains the international code and is 10 digits long");
            }
        }
    }
    public static String getMessageContent(){
        while (true){
            //Prompt the user to enter the message
            String message =  JOptionPane.showInputDialog("Enter your message");
            //Validate the message length
            if (message.length() <= 250){
                 JOptionPane.showMessageDialog(null, "Message sent");
            }
                //Ensures the message is less than 250 characters
                else{
                     JOptionPane.showMessageDialog(null, "Please enter a message of less than 250 characters");
                    }
        }  
    }
    private static void sendMessages(int totalMessages){
        
        int count = Integer.parseInt(input);
    
       
        messageManager manager = new messageManager();
        
    
        while (manager.canSendMoreMessages()) {
            //promt user for recipient number
         String recipient = JOptionPane.showInputDialog("Enter recipient number (+27xxxxxxxxx):");
         //promt user for message
         String content = JOptionPane.showInputDialog("Enter message (max 250 chars):");
            
            //check the message length and break if condition is not met
            if (content.length() > 250) {
                JOptionPane.showMessageDialog(null, 
                "Message exceeds 250 characters by " + (content.length()-250));
                break;
            }
            //continue if condition is met
            else{
            continue;
            }
        }
        
        Message message = new Message("+27834557896", "Did you get the cake?","Sent");
        String[] options = {"Send", "Disregard", "Store"};
        //promt user to choose an option
        int action = JOptionPane.showOptionDialog(null, "Choose action:", "Message Options", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);
         switch (action) {
            case 0: manager.addMessage(message, "SEND"); 
                break;
            case 1: manager.addMessage(message, "DISREGARD");
                break;
            case 2: manager.addMessage(message, "STORE");
                break;
        }
         JOptionPane.showMessageDialog(null, "Finished sending " + count + " messages.");
         if (count == totalMessages){
                JOptionPane.showMessageDialog(null, "You have reached the maximum number of messages");
            }
    }
    
    //Add JSON file 
    //OpenAI.(2025). ChatGPT(April 10 version.https://chatgpt.com/c/67f832f3-9424-8002-9024-b2da62f7d8f9
    //https://youtu.be/pJt-AYrmopo?si=RzcP6vgtmE-zpwQl
    private static final String FILE_NAME = "messages.json";
    //Saves messages to json file
    public static void saveMessageToJSON(Message message){
    List<Message> messages = loadMessagesFromJson();
    //add the new message
    
    //Write all messages back to file
    try(FileWriter writer = new FileWriter(FILE_NAME)){
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        gson.toJson(messages, writer);
        JOptionPane.showMessageDialog(null, "Message sucessfully sent");
        String input = JOptionPane.showInputDialog("Press 0 to delete message");
        if ("0".equals(input)){
            messages.remove(message);
            gson.toJson(messages);
            JOptionPane.showMessageDialog(null, "Message sucessfully deleted");
        }
        else {
            JOptionPane.showMessageDialog(null, "Message sucessfully stored");;
        }
    }
    catch (IOException e) {
        JOptionPane.showMessageDialog(null, "Failed to save message: " + e.getMessage());
    }
    }
    //Load messages from JSON file
    public static List<Message> loadMessagesFromJson(){
        File file = new File(FILE_NAME);
        if (!file.exists()){
            return new ArrayList<>();
        }
        try (Reader reader = new FileReader(file)){
            Gson gson = new Gson();
            Message[] messageArray = gson.fromJson(reader, Message[].class);
            return new ArrayList<>(Arrays.asList(messageArray));
        }
        catch (IOException e){
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    private String username;

    public Registration() {
        this.registeredUsername = username;
    }
        
}
